'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const { WebSocketServer, WebSocket } = require('ws');

const PORT = Number(process.env.PORT || 8080);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
const CLIENT_DIR = path.join(__dirname, '..', 'client');
const DATA_DIR = path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, 'game.sqlite'));
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    username_key TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL DEFAULT '',
    coins INTEGER NOT NULL DEFAULT 1000 CHECK(coins >= 0),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS coin_ledger (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username_key TEXT NOT NULL,
    amount INTEGER NOT NULL,
    reason TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);
try { db.exec("ALTER TABLE users ADD COLUMN password_hash TEXT NOT NULL DEFAULT ''"); } catch {}
const findUser = db.prepare('SELECT id, username, username_key AS usernameKey, password_hash AS passwordHash, coins FROM users WHERE username_key = ?');
const createUser = db.prepare('INSERT INTO users (id, username, username_key, coins, password_hash) VALUES (?, ?, ?, ?, ?)');
const sessions = new Map();
const addCoins = db.prepare('UPDATE users SET coins = coins + ?, updated_at = CURRENT_TIMESTAMP WHERE username_key = ?');
const setCoins = db.prepare('UPDATE users SET coins = ?, updated_at = CURRENT_TIMESTAMP WHERE username_key = ?');
const logCoins = db.prepare('INSERT INTO coin_ledger (username_key, amount, reason) VALUES (?, ?, ?)');
const usersOnline = new Map();
const rooms = new Map();
const mime = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.json':'application/json; charset=utf-8' };

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/health') { res.writeHead(200, {'content-type':'application/json'}); return res.end(JSON.stringify({ok:true, name:'Chibi Tuyen Dau', storage:'sqlite'})); }
  if (req.method === 'POST' && req.url === '/api/auth/register') return register(req, res);
  if (req.method === 'POST' && req.url === '/api/auth/login') return login(req, res);
  if (req.method === 'GET' && req.url === '/api/auth/me') return currentUser(req, res);
  if (req.method === 'POST' && req.url === '/api/auth/logout') return logout(req, res);
  if (req.method === 'POST' && req.url === '/api/admin/grant') return adminGrant(req, res);
  let pathname;
  try { pathname = decodeURIComponent((req.url || '/').split('?')[0]); } catch { res.writeHead(400); return res.end('Bad path'); }
  if (pathname === '/') pathname = '/index.html';
  const file = path.resolve(CLIENT_DIR, '.' + pathname);
  if (!file.startsWith(CLIENT_DIR + path.sep) && file !== path.join(CLIENT_DIR, 'index.html')) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, {'content-type': mime[path.extname(file)] || 'application/octet-stream', 'cache-control':'no-store'}); res.end(data);
  });
});

function json(res, status, body) { res.writeHead(status, {'content-type':'application/json; charset=utf-8'}); res.end(JSON.stringify(body)); }
function readJson(req, cb) {
  let body = '';
  req.on('data', chunk => { body += chunk; if (body.length > 8192) { req.destroy(); } });
  req.on('end', () => { try { cb(null, JSON.parse(body || '{}')); } catch { cb(new Error('Invalid JSON')); } });
}
function getOrCreateUser(username, initialCoins = 1000) {
  const key = username.toLowerCase();
  let user = findUser.get(key);
  if (!user) {
    createUser.run(crypto.randomUUID(), username, key, initialCoins, '');
    user = findUser.get(key);
  }
  return user;
}
function safeUsername(value) {
  const username = String(value || '').trim();
  return /^[\p{L}\p{N}_]{3,24}$/u.test(username) ? username : null;
}
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.pbkdf2Sync(password, salt, 210000, 32, 'sha256').toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const [salt, expected] = String(stored || '').split(':');
  if (!salt || !expected) return false;
  const actual = Buffer.from(hashPassword(password, salt).split(':')[1], 'hex');
  const wanted = Buffer.from(expected, 'hex');
  return actual.length === wanted.length && crypto.timingSafeEqual(actual, wanted);
}
function bearer(req) { const h = req.headers.authorization || ''; return h.startsWith('Bearer ') ? h.slice(7) : ''; }
function authenticatedUser(req) { const session = sessions.get(bearer(req)); if (!session || session.expires < Date.now()) return null; return findUser.get(session.usernameKey) || null; }
function register(req, res) { readJson(req, (err, data) => {
  if (err) return json(res, 400, {error:'Dữ liệu không hợp lệ.'});
  const username = safeUsername(data.username); const password = String(data.password || '');
  if (!username) return json(res, 400, {error:'Tên tài khoản phải dài 3–24 ký tự, chỉ gồm chữ, số hoặc dấu gạch dưới.'});
  if (password.length < 8 || password.length > 128) return json(res, 400, {error:'Mật khẩu phải dài 8–128 ký tự.'});
  const key = username.toLowerCase(); if (findUser.get(key)) return json(res, 409, {error:'Tên tài khoản đã tồn tại.'});
  try { createUser.run(crypto.randomUUID(), username, key, 1000, hashPassword(password)); } catch { return json(res, 409, {error:'Không thể tạo tài khoản này.'}); }
  return issueSession(res, findUser.get(key));
}); }
function login(req, res) { readJson(req, (err, data) => {
  if (err) return json(res, 400, {error:'Dữ liệu không hợp lệ.'});
  const username = safeUsername(data.username); const password = String(data.password || '');
  if (!username || !password) return json(res, 400, {error:'Nhập tài khoản và mật khẩu hợp lệ.'});
  const user = findUser.get(username.toLowerCase());
  if (!user || !verifyPassword(password, user.passwordHash)) return json(res, 401, {error:'Tên tài khoản hoặc mật khẩu không đúng.'});
  return issueSession(res, user);
}); }
function issueSession(res, user) { const token = crypto.randomBytes(32).toString('hex'); sessions.set(token, {usernameKey:user.usernameKey, expires:Date.now()+7*24*60*60*1000}); return json(res, 200, {ok:true, token, expiresIn:604800, user:{username:user.username, coins:user.coins}}); }
function currentUser(req, res) { const user = authenticatedUser(req); return user ? json(res, 200, {user:{username:user.username, coins:user.coins}}) : json(res, 401, {error:'Phiên đăng nhập hết hạn.'}); }
function logout(req, res) { sessions.delete(bearer(req)); return json(res, 200, {ok:true}); }
function adminGrant(req, res) {
  if (!ADMIN_TOKEN) return json(res, 503, {error:'Admin disabled: set ADMIN_TOKEN on server.'});
  readJson(req, (err, data) => {
    if (err) return json(res, 400, {error:'Bad JSON'});
    const auth = req.headers.authorization || '';
    if (auth !== `Bearer ${ADMIN_TOKEN}`) return json(res, 401, {error:'Unauthorized'});
    const username = safeName(data.username);
    const amount = Number(data.amount);
    if (!username || !Number.isSafeInteger(amount) || amount < 1 || amount > 1_000_000_000) return json(res, 400, {error:'Provide username and integer amount 1..1,000,000,000.'});
    try {
      db.exec('BEGIN IMMEDIATE');
      const user = findUser.get(username.toLowerCase());
      if (!user) { db.exec('ROLLBACK'); return json(res, 404, {error:'Không tìm thấy tài khoản. Người chơi cần đăng ký trước.'}); }
      if (user.coins > Number.MAX_SAFE_INTEGER - amount) { db.exec('ROLLBACK'); return json(res, 400, {error:'Coin balance limit reached.'}); }
      addCoins.run(amount, user.usernameKey);
      logCoins.run(user.usernameKey, amount, 'admin_grant');
      const updated = findUser.get(user.usernameKey);
      db.exec('COMMIT');
      broadcastUser(user.usernameKey, {type:'wallet', coins:updated.coins});
      return json(res, 200, {ok:true, username:updated.username, coins:updated.coins});
    } catch (e) {
      try { db.exec('ROLLBACK'); } catch {}
      return json(res, 500, {error:'Could not save coin balance.'});
    }
  });
}
const wss = new WebSocketServer({ server, path:'/ws' });
function send(ws, data) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); }
function roomBroadcast(room, data) { for (const peer of room.clients) send(peer, data); }
function broadcastUser(key, data) { for (const peer of wss.clients) if (peer.userKey === key) send(peer, data); }
function safeName(v) { return String(v || 'Player').trim().replace(/[^\p{L}\p{N}_ -]/gu,'').slice(0,24) || 'Player'; }

wss.on('connection', ws => {
  ws.on('message', raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return send(ws,{type:'error', message:'Invalid message'}); }
    if (msg.type === 'join') {
      const session = sessions.get(String(msg.token || ''));
      if (!session || session.expires < Date.now()) return send(ws,{type:'error',message:'Bạn cần đăng nhập lại.'});
      const user = findUser.get(session.usernameKey); if (!user || !user.passwordHash) return send(ws,{type:'error',message:'Tài khoản không hợp lệ.'});
      const key = user.usernameKey;
      ws.userKey = key; ws.username = user.username;
      const roomCode = String(msg.room || 'PRACTICE').trim().toUpperCase().replace(/[^A-Z0-9-]/g,'').slice(0,12) || 'PRACTICE';
      if (ws.room) ws.room.clients.delete(ws);
      let room = rooms.get(roomCode); if (!room) { room = { code:roomCode, clients:new Set(), turn:0, shots:0 }; rooms.set(roomCode,room); }
      ws.room = room; room.clients.add(ws);
      send(ws,{type:'joined', username:user.username, coins:user.coins, room:room.code, players:room.clients.size});
      roomBroadcast(room,{type:'players', players:[...room.clients].map(p=>p.username)});
      return;
    }
    if (!ws.room || !ws.username) return send(ws,{type:'error',message:'Join a room first.'});
    if (msg.type === 'shot') {
      const angle = Math.max(5, Math.min(85, Number(msg.angle)||45));
      const power = Math.max(10, Math.min(100, Number(msg.power)||60));
      ws.room.turn++; ws.room.shots++;
      roomBroadcast(ws.room,{type:'shot', username:ws.username, angle, power, turn:ws.room.turn, shotId:crypto.randomUUID()});
      // Demo reward only. Persistent wallet is updated in SQLite; replace with validated match results.
      try {
        const user = findUser.get(ws.userKey);
        if (user && user.coins < Number.MAX_SAFE_INTEGER - 10) {
          addCoins.run(10, ws.userKey); logCoins.run(ws.userKey, 10, 'demo_shot_reward');
          const updated = findUser.get(ws.userKey);
          broadcastUser(ws.userKey,{type:'wallet',coins:updated.coins});
        }
      } catch { send(ws,{type:'error',message:'Không lưu được xu. Vui lòng thử lại.'}); }
    }
    if (msg.type === 'ping') send(ws,{type:'pong', at:Date.now()});
  });
  ws.on('close', () => { if (ws.room) { ws.room.clients.delete(ws); roomBroadcast(ws.room,{type:'players',players:[...ws.room.clients].map(p=>p.username)}); if (!ws.room.clients.size) rooms.delete(ws.room.code); } });
});
server.listen(PORT, () => console.log(`Chibi Tuyen Dau listening on http://localhost:${PORT}`));
process.on('SIGINT', () => { try { db.close(); } finally { process.exit(0); } });
process.on('SIGTERM', () => { try { db.close(); } finally { process.exit(0); } });
