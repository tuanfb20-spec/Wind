# Chibi Tuyến Đấu — Android build package (v0.4)

Original mobile-first 2D trajectory game prototype. It uses original canvas-drawn characters and does not include Gunny assets/code.

## Important status
This repository contains the Android wrapper configuration and a cloud build workflow. The APK itself has **not** been compiled in this workspace because Android SDK/Gradle and external network access are unavailable here. The workflow below builds a debug APK on GitHub Actions after the project is uploaded to a GitHub repository.

The APK is a test build, not a production release. It needs a real deployed server URL to use account registration, login, multiplayer rooms, and server-backed coins. The app includes a “Kết nối máy chủ” field for an HTTPS server address. Do not use `localhost` on a phone to refer to a remote server.

## Android APK build via GitHub Actions
1. Create a private GitHub repository and upload the contents of this folder.
2. Open **Actions** and enable workflows if GitHub asks.
3. Select **Build Android APK** and choose **Run workflow** (or push to `main`).
4. When it finishes, open the workflow run and download the artifact `chibi-tuyen-dau-debug-apk`.
5. Extract the artifact; it contains `app-debug.apk`. On Android, allow installation from that source if needed.

This workflow creates a debug APK for testing, not a Play Store-signed release. Keep the repository private if it contains any private server configuration; never commit the admin token.

## Run the server
Requirements: Node.js 22+ and npm.

```bash
cd server
npm install
ADMIN_TOKEN='replace-with-a-long-random-secret' npm start
```

Deploy the server to a host supporting HTTPS and WebSockets/WSS, then enter its HTTPS base URL in the app. The SQLite database is stored at `server/data/game.sqlite` and must be backed up.

## Prototype features
- Aim-angle and power controls, projectile animation, and simple terrain.
- Register/login with PBKDF2 password hashes.
- SQLite coin balance and transaction ledger.
- Online room synchronization using WebSocket.
- Server-side admin grant endpoint protected by `ADMIN_TOKEN`.
- Local unlimited-coins switch is only a local visual/demo feature; it does not grant online currency.

## Not production-ready
Before public release, add persistent/revocable sessions, rate limiting, HTTPS/WSS deployment, account lock support, server-authoritative match validation, anti-cheat, reconnection handling, backups/monitoring, privacy and terms pages, and a signed release build. The current server does not implement a complete production admin console or robust account locking. Do not use this demo for real-money purchases.
